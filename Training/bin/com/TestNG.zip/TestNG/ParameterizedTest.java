package com.TestNG;

import org.testng.annotations.*;

public class ParameterizedTest {
	   
	@Test
	@Parameters("Browser")
	public void printName(String browser) {
		if(browser.equalsIgnoreCase("chrome")) {
			System.set
			driver = new ChromeDriver();
		}
		else if (browser.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
		}
		el
	}
	
	@DataProvider(name = "test1")
	public static Object[][] checkEven() {
	    return new Object[][] {{2}, {6}, {5}};
	}
	
	@Test(dataProvider = "test1")
	public void checkEvenOrOdd(int inputNumber) {
		if(inputNumber%2 == 0) {
			System.out.println("Even");
		}
		else {
			System.out.println("Odd");
		}
	}
  
}