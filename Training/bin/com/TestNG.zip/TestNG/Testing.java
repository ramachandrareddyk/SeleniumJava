package com.TestNG;

import org.testng.annotations.Test;

public class Testing {

	@Test
	public void test1() {
		System.out.println("My test method1");
	}
	
	@Test
	public void test2() {
		System.out.println("My test method2");
	}
}
