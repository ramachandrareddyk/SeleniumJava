package com.Cucumber.Features;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Test {

	@Given("User opens the application")
	public void openAppication() {
		System.out.println("open application");
	}
	
	@And("user enters username as '(.*)'")
	public void enterUsername(String username) {
		System.out.println(username);
	}
	
	@And("user enters passsword as '(.*)'")
	public void enterPswd(String pswd) {
		System.out.println(pswd);
	}
	
	@And("user clicks login button")
	public void clickLogin() {
		System.out.println("click login");
	}
	
	@Then("check if user is on home page")
	public void validateHomePage() {
		System.out.println("Home page");
	}
}
