package com.JUnit;

import org.junit.Test;

public class PrintMessage {

	@Test
	public void print() {
		System.out.println("Hello! Welcome to JUNIT");
	}
}
